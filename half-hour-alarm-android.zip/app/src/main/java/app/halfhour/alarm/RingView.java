package app.halfhour.alarm;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.View;

/** The progress ring: how far we are into the current half hour, with the time left in the middle. */
public class RingView extends View {
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint prog = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint big = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint small = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box = new RectF();
    private float progress = 0f;
    private String time = "30:00";
    private String sub = "";

    public RingView(Context c, int accent, int line, int fg, int muted) {
        super(c);
        float stroke = dp(10);

        track.setStyle(Paint.Style.STROKE);
        track.setStrokeWidth(stroke);
        track.setColor(line);

        prog.setStyle(Paint.Style.STROKE);
        prog.setStrokeWidth(stroke);
        prog.setStrokeCap(Paint.Cap.ROUND);
        prog.setColor(accent);

        big.setColor(fg);
        big.setTextAlign(Paint.Align.CENTER);
        big.setTextSize(sp(52));
        big.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));

        small.setColor(muted);
        small.setTextAlign(Paint.Align.CENTER);
        small.setTextSize(sp(14));
    }

    private float dp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private float sp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, getResources().getDisplayMetrics());
    }

    /** progress goes from 0 to 1 across one half hour. */
    public void set(float progress, String time, String sub) {
        this.progress = Math.max(0f, Math.min(1f, progress));
        this.time = time;
        this.sub = sub;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        float cx = w / 2f;
        float cy = h / 2f;
        float r = Math.min(w, h) / 2f - track.getStrokeWidth();
        box.set(cx - r, cy - r, cx + r, cy + r);

        canvas.drawCircle(cx, cy, r, track);
        if (progress > 0f) canvas.drawArc(box, -90f, 360f * progress, false, prog);

        Paint.FontMetrics fm = big.getFontMetrics();
        float ty = cy - (fm.ascent + fm.descent) / 2f - dp(8);
        canvas.drawText(time, cx, ty, big);
        canvas.drawText(sub, cx, ty + dp(32), small);
    }
}
