package app.halfhour.alarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** After a restart or an app update the system forgets alarms, so put the running one back. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent == null ? null : intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(a) && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) return;
        if (!Scheduler.prefs(ctx).getBoolean("running", false)) return;
        Scheduler.scheduleNext(ctx);
        try {
            ctx.startForegroundService(new Intent(ctx, AlarmService.class).setAction(AlarmService.ACTION_START));
        } catch (Exception ignored) {
        }
    }
}
