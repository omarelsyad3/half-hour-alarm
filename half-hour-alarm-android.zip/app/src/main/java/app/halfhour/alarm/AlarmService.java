package app.halfhour.alarm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Icon;
import android.os.IBinder;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Foreground service: keeps the app alive while the timer runs and shows the notification with a Stop button. */
public class AlarmService extends Service {
    static final String ACTION_START = "app.halfhour.alarm.START";
    static final String ACTION_STOP = "app.halfhour.alarm.STOP";
    private static final String CHANNEL = "running";
    private static final int NOTIF_ID = 1;

    static volatile boolean alive = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        alive = true;
    }

    @Override
    public void onDestroy() {
        alive = false;
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            Scheduler.stop(this);
            stopForeground(Service.STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }

        // A service started with startForegroundService must call startForeground quickly, so do it first.
        try {
            startForeground(NOTIF_ID, build(this));
        } catch (Exception ignored) {
        }

        if (!Scheduler.prefs(this).getBoolean("running", false)) {
            stopForeground(Service.STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    static Notification build(Context ctx) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "المنبّه شغّال", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }

        SharedPreferences p = Scheduler.prefs(ctx);
        long now = System.currentTimeMillis();
        long start = p.getLong("startedAt", now);
        String next = new SimpleDateFormat("h:mm a", new Locale("ar", "EG"))
                .format(new Date(Scheduler.nextAt(start, now)));

        PendingIntent open = PendingIntent.getActivity(ctx, 0,
                new Intent(ctx, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(ctx, 2,
                new Intent(ctx, AlarmService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Action stopAction = new Notification.Action.Builder(
                Icon.createWithResource(ctx, android.R.drawable.ic_menu_close_clear_cancel), "إيقاف", stop).build();

        return new Notification.Builder(ctx, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("منبّه نص ساعة شغّال")
                .setContentText("التنبيه الجاي الساعة " + next + " · عدد التنبيهات " + p.getInt("count", 0))
                .setContentIntent(open)
                .addAction(stopAction)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
    }

    /** Refreshes the notification text (next time and count) while the service is running. */
    static void refresh(Context ctx) {
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.notify(NOTIF_ID, build(ctx));
        } catch (Exception ignored) {
        }
    }
}
