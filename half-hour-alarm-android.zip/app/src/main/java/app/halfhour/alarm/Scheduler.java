package app.halfhour.alarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/** Keeps the 30-minute cadence. Alarms are set with setAlarmClock, which needs no special permission and fires exactly, even in Doze. */
final class Scheduler {
    static final long INTERVAL = 30L * 60L * 1000L;
    static final String ACTION_TICK = "app.halfhour.alarm.TICK";

    private Scheduler() {}

    static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences("hh", Context.MODE_PRIVATE);
    }

    /** The next alert time after "now", counted from the moment the user pressed Start. */
    static long nextAt(long start, long now) {
        if (now < start) return start + INTERVAL;
        return start + ((now - start) / INTERVAL + 1) * INTERVAL;
    }

    private static PendingIntent alarmIntent(Context ctx) {
        Intent i = new Intent(ctx, AlarmReceiver.class).setAction(ACTION_TICK);
        return PendingIntent.getBroadcast(ctx, 1, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void scheduleNext(Context ctx) {
        SharedPreferences p = prefs(ctx);
        long now = System.currentTimeMillis();
        long start = p.getLong("startedAt", now);
        // A small offset so an alarm that fires a moment early never schedules itself again.
        long at = nextAt(start, now + 2000L);
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        PendingIntent show = PendingIntent.getActivity(ctx, 3, new Intent(ctx, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), alarmIntent(ctx));
    }

    static void cancel(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        am.cancel(alarmIntent(ctx));
    }

    /** Stops everything: the pending alarm, the flag and any sound or vibration in progress. */
    static void stop(Context ctx) {
        cancel(ctx);
        prefs(ctx).edit().putBoolean("running", false).apply();
        AlertPlayer.stopAll(ctx);
    }
}
