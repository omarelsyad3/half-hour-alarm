package app.halfhour.alarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/** Wakes up on every half hour: sets the next alarm first, then plays the alert. */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        SharedPreferences p = Scheduler.prefs(ctx);
        if (!p.getBoolean("running", false)) return;

        // Keep the cadence even if anything below fails.
        Scheduler.scheduleNext(ctx);
        p.edit().putInt("count", p.getInt("count", 0) + 1).apply();

        if (AlarmService.alive) {
            AlarmService.refresh(ctx);
        } else {
            try {
                ctx.startForegroundService(new Intent(ctx, AlarmService.class).setAction(AlarmService.ACTION_START));
            } catch (Exception ignored) {
                // The alert below still plays; the service only keeps the process alive and shows the notification.
            }
        }

        final PendingResult pending = goAsync();
        AlertPlayer.fire(ctx, new Runnable() {
            @Override
            public void run() {
                pending.finish();
            }
        });
    }
}
