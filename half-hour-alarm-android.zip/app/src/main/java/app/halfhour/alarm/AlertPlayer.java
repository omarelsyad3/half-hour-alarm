package app.halfhour.alarm;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

/** Plays the alert: either the chosen sound (on the alarm volume) or a vibration pattern, never both. */
final class AlertPlayer {
    /** Pattern per strength: light, medium, strong. The first number is the wait before the first buzz. */
    static final long[][] PATTERNS = {
            {0, 250},
            {0, 400, 150, 400},
            {0, 700, 200, 700, 200, 700}
    };
    /** Kept under the 10 seconds the system allows a broadcast receiver to run. */
    private static final long SOUND_MS = 6000L;
    private static final Handler H = new Handler(Looper.getMainLooper());
    private static Ringtone current;

    private AlertPlayer() {}

    /** Fires one alert. "done" (may be null) runs when the sound or vibration has finished. */
    static void fire(Context ctx, final Runnable done) {
        Context app = ctx.getApplicationContext();
        SharedPreferences p = Scheduler.prefs(app);

        PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
        final PowerManager.WakeLock lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "halfhour:alert");
        lock.acquire(15000L);

        long holdMs;
        if ("vibe".equals(p.getString("mode", "sound"))) {
            int idx = Math.max(0, Math.min(2, p.getInt("vibe", 1)));
            long[] pattern = PATTERNS[idx];
            vibrate(app, pattern);
            long total = 0;
            for (long x : pattern) total += x;
            holdMs = total + 300L;
        } else {
            playSound(app, p.getString("sound", ""));
            holdMs = SOUND_MS;
        }

        H.postDelayed(new Runnable() {
            @Override
            public void run() {
                stopSound();
                if (lock.isHeld()) lock.release();
                if (done != null) done.run();
            }
        }, holdMs);
    }

    private static void playSound(Context ctx, String uriStr) {
        stopSound();
        try {
            Uri uri = (uriStr == null || uriStr.isEmpty())
                    ? RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    : Uri.parse(uriStr);
            if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(ctx, uri);
            if (r == null) return;
            r.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            r.play();
            current = r;
        } catch (Exception ignored) {
        }
    }

    @SuppressWarnings("deprecation")
    private static void vibrate(Context ctx, long[] pattern) {
        try {
            Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null || !v.hasVibrator()) return;
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            v.vibrate(VibrationEffect.createWaveform(pattern, -1), attrs);
        } catch (Exception ignored) {
        }
    }

    static void stopSound() {
        if (current != null) {
            try {
                current.stop();
            } catch (Exception ignored) {
            }
            current = null;
        }
    }

    static void stopAll(Context ctx) {
        stopSound();
        try {
            Vibrator v = (Vibrator) ctx.getApplicationContext().getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) v.cancel();
        } catch (Exception ignored) {
        }
    }
}
