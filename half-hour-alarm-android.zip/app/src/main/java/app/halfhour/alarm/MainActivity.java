package app.halfhour.alarm;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_RINGTONE = 1;
    private static final int REQ_FILE = 2;
    private static final int REQ_NOTIF = 10;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final String DEFAULT_SOUND_NAME = "نغمة المنبّه الافتراضية";

    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean dark;
    private int cBg, cSurface, cFg, cMuted, cLine, cAccent, cAccentFg;

    private RingView ring;
    private TextView pill, stStart, stCount, stNext, soundNameView, batteryNote;
    private GradientDrawable pillBg;
    private Button mainBtn, batteryBtn;
    private View soundPanel, vibePanel;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = Scheduler.prefs(this);

        dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        if (dark) {
            cBg = 0xFF0C1719; cSurface = 0xFF142428; cFg = 0xFFE3EEEF; cMuted = 0xFF93AEB2;
            cLine = 0xFF2A4044; cAccent = 0xFF43BBCB; cAccentFg = 0xFF062A30;
        } else {
            cBg = 0xFFEDF2F2; cSurface = 0xFFFFFFFF; cFg = 0xFF10262A; cMuted = 0xFF4D676C;
            cLine = 0xFFCBD9DA; cAccent = 0xFF0B7285; cAccentFg = 0xFFFFFFFF;
        }
        getWindow().setStatusBarColor(cBg);
        getWindow().setNavigationBarColor(cBg);
        if (!dark) {
            View decor = getWindow().getDecorView();
            decor.setSystemUiVisibility(decor.getSystemUiVisibility()
                    | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }

        setContentView(buildUi());
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateBatteryRow();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    // ---------------------------------------------------------------- UI

    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(topDp);
        return p;
    }

    private GradientDrawable rounded(int fill, int stroke, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private Button button(String label, boolean filled) {
        Button bt = new Button(this);
        bt.setAllCaps(false);
        bt.setText(label);
        bt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        bt.setTextColor(filled ? cAccentFg : cAccent);
        bt.setBackground(filled ? rounded(cAccent, 0, 12) : rounded(Color.TRANSPARENT, cAccent, 12));
        bt.setStateListAnimator(null);
        bt.setMinHeight(dp(48));
        bt.setMinimumHeight(dp(48));
        return bt;
    }

    private RadioButton radio(String label, int id) {
        RadioButton r = new RadioButton(this);
        r.setId(id);
        r.setText(label);
        r.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        r.setTextColor(cFg);
        r.setButtonTintList(ColorStateList.valueOf(cAccent));
        r.setPadding(dp(6), dp(8), dp(14), dp(8));
        return r;
    }

    private TextView addStat(LinearLayout row, String label) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.addView(text(label, 13, cMuted, false));
        TextView value = text("—", 18, cFg, true);
        cell.addView(value);
        row.addView(cell, new LinearLayout.LayoutParams(0, WRAP, 1f));
        return value;
    }

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackgroundColor(cBg);
        sv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(20), dp(20), dp(20), dp(32));
        sv.addView(col, new ViewGroup.LayoutParams(MATCH, WRAP));

        // Title and state pill
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(text("منبّه نص ساعة", 21, cFg, true), new LinearLayout.LayoutParams(0, WRAP, 1f));
        pill = text("واقف", 13, cMuted, false);
        pill.setPadding(dp(12), dp(3), dp(12), dp(3));
        pillBg = rounded(Color.TRANSPARENT, cLine, 20);
        pill.setBackground(pillBg);
        top.addView(pill, new LinearLayout.LayoutParams(WRAP, WRAP));
        col.addView(top, new LinearLayout.LayoutParams(MATCH, WRAP));

        // Ring
        ring = new RingView(this, cAccent, cLine, cFg, cMuted);
        LinearLayout.LayoutParams rp = lp(dp(280), dp(280), 20);
        rp.gravity = Gravity.CENTER_HORIZONTAL;
        col.addView(ring, rp);

        // Start / Stop
        mainBtn = button("ابدأ", true);
        mainBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        mainBtn.setTypeface(Typeface.DEFAULT_BOLD);
        mainBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (prefs.getBoolean("running", false)) stopTimer();
                else startTimer();
                refresh();
            }
        });
        col.addView(mainBtn, lp(MATCH, dp(60), 18));

        // Stats
        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.setPadding(0, dp(16), 0, dp(4));
        stStart = addStat(stats, "بدأ الساعة");
        stCount = addStat(stats, "عدد التنبيهات");
        stNext = addStat(stats, "التنبيه الجاي");
        col.addView(stats, lp(MATCH, WRAP, 18));

        // Settings card
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(rounded(cSurface, cLine, 16));
        col.addView(card, lp(MATCH, WRAP, 18));

        card.addView(text("طريقة التنبيه", 15, cFg, true));
        final RadioGroup modeGroup = new RadioGroup(this);
        modeGroup.setOrientation(RadioGroup.HORIZONTAL);
        final int idSound = View.generateViewId();
        final int idVibe = View.generateViewId();
        modeGroup.addView(radio("صوت", idSound));
        modeGroup.addView(radio("اهتزاز بس", idVibe));
        card.addView(modeGroup, lp(MATCH, WRAP, 4));

        // Sound panel
        LinearLayout sp = new LinearLayout(this);
        sp.setOrientation(LinearLayout.VERTICAL);
        soundPanel = sp;
        sp.addView(text("الصوت المختار", 15, cFg, true), lp(MATCH, WRAP, 16));
        soundNameView = text("", 15, cMuted, false);
        sp.addView(soundNameView, lp(MATCH, WRAP, 2));
        Button pickSystem = button("اختار من نغمات التليفون", false);
        pickSystem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickRingtone();
            }
        });
        sp.addView(pickSystem, lp(MATCH, WRAP, 10));
        Button pickFile = button("اختار ملف صوت من التليفون", false);
        pickFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickFile();
            }
        });
        sp.addView(pickFile, lp(MATCH, WRAP, 8));
        Button pickDefault = button("الصوت الافتراضي", false);
        pickDefault.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSound("", DEFAULT_SOUND_NAME);
            }
        });
        sp.addView(pickDefault, lp(MATCH, WRAP, 8));
        sp.addView(text("مستوى الصوت هو مستوى صوت المنبّه في التليفون. اضبطه من أزرار الصوت، واختار \"المنبّه\" لو ظهرت أكتر من شريط.", 13, cMuted, false), lp(MATCH, WRAP, 10));
        card.addView(sp, new LinearLayout.LayoutParams(MATCH, WRAP));

        // Vibration panel
        LinearLayout vp = new LinearLayout(this);
        vp.setOrientation(LinearLayout.VERTICAL);
        vibePanel = vp;
        vp.addView(text("قوة الاهتزاز", 15, cFg, true), lp(MATCH, WRAP, 16));
        final RadioGroup vibeGroup = new RadioGroup(this);
        vibeGroup.setOrientation(RadioGroup.HORIZONTAL);
        final int[] vibeIds = {View.generateViewId(), View.generateViewId(), View.generateViewId()};
        String[] vibeNames = {"خفيف", "متوسط", "قوي"};
        for (int i = 0; i < 3; i++) vibeGroup.addView(radio(vibeNames[i], vibeIds[i]));
        vp.addView(vibeGroup, lp(MATCH, WRAP, 4));
        vp.addView(text("الاهتزاز بيشتغل والشاشة مقفولة. لو ما حسّيتش بيه، شوف إن وضع الاهتزاز شغّال في إعدادات التليفون.", 13, cMuted, false), lp(MATCH, WRAP, 8));
        card.addView(vp, new LinearLayout.LayoutParams(MATCH, WRAP));

        // Initial values, set before the listeners are attached
        String mode = prefs.getString("mode", "sound");
        modeGroup.check("vibe".equals(mode) ? idVibe : idSound);
        soundPanel.setVisibility("vibe".equals(mode) ? View.GONE : View.VISIBLE);
        vibePanel.setVisibility("vibe".equals(mode) ? View.VISIBLE : View.GONE);
        vibeGroup.check(vibeIds[Math.max(0, Math.min(2, prefs.getInt("vibe", 1)))]);
        soundNameView.setText(prefs.getString("soundName", DEFAULT_SOUND_NAME));

        modeGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup g, int checkedId) {
                boolean vibe = checkedId == idVibe;
                prefs.edit().putString("mode", vibe ? "vibe" : "sound").apply();
                soundPanel.setVisibility(vibe ? View.GONE : View.VISIBLE);
                vibePanel.setVisibility(vibe ? View.VISIBLE : View.GONE);
            }
        });
        vibeGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup g, int checkedId) {
                for (int i = 0; i < 3; i++) {
                    if (vibeIds[i] == checkedId) prefs.edit().putInt("vibe", i).apply();
                }
            }
        });

        // Test
        Button test = button("جرّب التنبيه دلوقتي", false);
        test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertPlayer.fire(MainActivity.this, null);
            }
        });
        card.addView(test, lp(MATCH, WRAP, 20));

        // Battery
        batteryNote = text("", 13, cMuted, false);
        card.addView(batteryNote, lp(MATCH, WRAP, 14));
        batteryBtn = button("خلّي التليفون ما يوقّفش المنبّه", false);
        batteryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestBatteryExemption();
            }
        });
        card.addView(batteryBtn, lp(MATCH, WRAP, 8));

        return sv;
    }

    // ---------------------------------------------------------------- timer

    private void startTimer() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
        long now = System.currentTimeMillis();
        prefs.edit().putBoolean("running", true).putLong("startedAt", now).putInt("count", 0).apply();
        Scheduler.scheduleNext(this);
        try {
            startForegroundService(new Intent(this, AlarmService.class).setAction(AlarmService.ACTION_START));
        } catch (Exception ignored) {
        }
    }

    private void stopTimer() {
        Scheduler.stop(this);
        stopService(new Intent(this, AlarmService.class));
    }

    private String clock(long ms) {
        return new SimpleDateFormat("h:mm a", new Locale("ar", "EG")).format(new Date(ms));
    }

    private void setPill(boolean on) {
        pill.setText(on ? "شغّال" : "واقف");
        pill.setTextColor(on ? cAccentFg : cMuted);
        pillBg.setColor(on ? cAccent : Color.TRANSPARENT);
        pillBg.setStroke(dp(1), on ? cAccent : cLine);
    }

    private void refresh() {
        boolean running = prefs.getBoolean("running", false);
        long now = System.currentTimeMillis();
        if (running) {
            long start = prefs.getLong("startedAt", now);
            long next = Scheduler.nextAt(start, now);
            long rem = Math.max(0L, next - now);
            int secs = (int) Math.ceil(rem / 1000.0);
            ring.set(1f - rem / (float) Scheduler.INTERVAL,
                    String.format(Locale.US, "%02d:%02d", secs / 60, secs % 60), "للتنبيه الجاي");
            stStart.setText(clock(start));
            stCount.setText(String.valueOf(prefs.getInt("count", 0)));
            stNext.setText(clock(next));
        } else {
            ring.set(0f, "30:00", "كل نص ساعة لحد ما توقّفه");
            stStart.setText("—");
            stCount.setText("—");
            stNext.setText("—");
        }
        mainBtn.setText(running ? "إيقاف" : "ابدأ");
        mainBtn.setTextColor(running ? cBg : cAccentFg);
        mainBtn.setBackground(rounded(running ? cFg : cAccent, 0, 12));
        setPill(running);
    }

    // ---------------------------------------------------------------- sound choice

    private void saveSound(String uri, String name) {
        prefs.edit().putString("sound", uri).putString("soundName", name).apply();
        soundNameView.setText(name);
    }

    private void pickRingtone() {
        Intent i = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL);
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false);
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "اختار صوت التنبيه");
        String cur = prefs.getString("sound", "");
        if (!cur.isEmpty()) i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(cur));
        try {
            startActivityForResult(i, REQ_RINGTONE);
        } catch (Exception ignored) {
        }
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(i, REQ_FILE);
        } catch (Exception ignored) {
        }
    }

    private String queryName(Uri uri) {
        String name = null;
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) name = c.getString(0);
        } catch (Exception ignored) {
        }
        return name;
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;

        if (req == REQ_RINGTONE) {
            Uri uri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            if (uri == null) {
                saveSound("", DEFAULT_SOUND_NAME);
            } else {
                String title = null;
                try {
                    Ringtone r = RingtoneManager.getRingtone(this, uri);
                    if (r != null) title = r.getTitle(this);
                } catch (Exception ignored) {
                }
                saveSound(uri.toString(), title != null ? title : "نغمة مختارة");
            }
            AlertPlayer.fire(this, null);
        } else if (req == REQ_FILE) {
            Uri uri = data.getData();
            if (uri == null) return;
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            String name = queryName(uri);
            saveSound(uri.toString(), name != null ? name : "ملف صوت");
            AlertPlayer.fire(this, null);
        }
    }

    // ---------------------------------------------------------------- battery

    private boolean ignoringBattery() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
    }

    private void updateBatteryRow() {
        boolean ok = ignoringBattery();
        batteryBtn.setVisibility(ok ? View.GONE : View.VISIBLE);
        batteryNote.setText(ok
                ? "التطبيق مستثنى من توفير البطارية، فالتنبيه هيجي في معاده."
                : "بعض التليفونات بتوقّف التطبيقات في الخلفية لتوفير البطارية. اسمح للتطبيق عشان التنبيه ما يتأخرش.");
    }

    private void requestBatteryExemption() {
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception ignored) {
            }
        }
    }
}
